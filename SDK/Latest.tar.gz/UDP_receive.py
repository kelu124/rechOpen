import socket
import struct
from array import array

UDP_IP = "192.168.1.23"
UDP_PORT = 7536

sock = socket.socket(socket.AF_INET, # Internet
                     socket.SOCK_DGRAM) # UDP
sock.bind((UDP_IP, UDP_PORT))


def ByteToHex( byteStr ):
    """
    Convert a byte string to it's int string representation e.g. for output.
    """
    
    out = []
    for x in byteStr:
	out.append(ord( x ))

    OutList = []
    N = len(out)/4
    
    for IList in range(N):
	tmp = int(out[IList*4])
	OutList.append(tmp)

    return out


#-------------------------------------------------------------------------------


FramesReceived = 0
while True:
    data, addr = sock.recvfrom(1036) # buffer size is (256+3)*4 bytes
    #print "[", FramesReceived, "] \treceived message:\t", len(ByteToHex(data))
    print "[", FramesReceived, "] \treceived message:\t", ByteToHex(data)


    FramesReceived = FramesReceived +1
	
