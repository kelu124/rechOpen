import socket
import struct
from array import array

UDP_IP = "192.168.1.23"
UDP_PORT = 7536

sock = socket.socket(socket.AF_INET, # Internet
                     socket.SOCK_DGRAM) # UDP
sock.bind((UDP_IP, UDP_PORT))

def ByteToHex( byteStr ):
    """
    Convert a byte string to it's hex string representation e.g. for output.
    """
    
    # Uses list comprehension which is a fractionally faster implementation than
    # the alternative, more readable, implementation below
    #   
    #    hex = []
    #    for aChar in byteStr:
    #        hex.append( "%02X " % ord( aChar ) )
    #
    #    return ''.join( hex ).strip()        
    out = []
    for x in byteStr:
	out.append(ord( x ))

    OutList = []
    N = len(out)/4
    
    for IList in range(N):
	if(out[IList*4]==0):
		OutList.append(out[IList*4+3])
        if(out[IList*4]<>0):
		OutList.append((-1)*(256-out[IList*4+3]))
    return OutList


def bytes_to_int(bytes):
  return int(bytes.encode('hex'), 16)

def int_from_bytes(b3, b2, b1, b0): 
  return (((((b3 << 8) + b2) << 8) + b1) << 8) + b0 

#-------------------------------------------------------------------------------


FramesReceived = 0
while True:
    data, addr = sock.recvfrom(272) # buffer size is 16*1024 bytes
    print "[", FramesReceived, "] \treceived message:\t", ByteToHex(data)


    FramesReceived = FramesReceived +1
	
